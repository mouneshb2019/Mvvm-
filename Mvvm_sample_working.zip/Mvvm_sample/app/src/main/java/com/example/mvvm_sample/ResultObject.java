package com.example.mvvm_sample;

public class ResultObject {

    private int num_results ;
    private String copyright;
    private String status;


    public String getcopyright() {
        return copyright;
    }
    public void setcopyright(String copyright) {
        this.copyright = copyright;
    }
    public void setstatus(String status) {
        this.status = status;
    }
    public int getnum_results() {
        return num_results;
    }

    public String gettstatus() {
       return status;
    }

    public ResultObject(int num_results , String copyright , String status ) {
        this.copyright = copyright ;
        this.status = status ;
        this.num_results = num_results ;
    }

}
