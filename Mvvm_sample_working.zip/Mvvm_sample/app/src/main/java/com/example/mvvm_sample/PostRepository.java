package com.example.mvvm_sample;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.view.View;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class PostRepository {
    private static PostRepository instance = null ;
    public static PostRepository getInstance() {
        if( instance == null) {
            return instance = new  PostRepository();
        }
        return instance ;
    }

    public LiveData<Post> getDatawithRetrofit() {

        final MutableLiveData<Post> postData = new MutableLiveData<>();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.nytimes.com/svc/movies/v2/")  //https://jsonplaceholder.typicode.com/") //(" http://www.mocky.io/") /*"https://my-json-server.typicode.com"*/
                .addConverterFactory(GsonConverterFactory.create()).build();

        JsonPlaceholderApi jsonplaceholderApi = retrofit.create(JsonPlaceholderApi.class);

        Call<Post> call = jsonplaceholderApi.getPosts();
        call.enqueue(new Callback<Post>() {
            @Override
            public void onResponse(Call<Post> call, Response<Post> response) {
                if(!response.isSuccessful()){
                   // textViewresult.setText(response.code());
                    return ;
                }
                Post posts = response.body();
                int len = posts.getNum_results();
                String copyright = posts.getcopyright();
                String status = posts.getstatus();
                postData.setValue(posts);

                //for( Post post : posts) {
                // String content = "";
                //   content += "id: " + post.getId() + "\n";
                //  content += "title " + post.getTitle() + "\n\n" ;
                //  textViewresult.append(content);
                // Picasso.with(getApplicationContext()).load(post.getThumbnailUrl()).into(imageViewresult);
                //}

               /* int count = 0 ;
                while ( count != len ){
                    String S1 = posts.getResults().get(count).getDisplay_title();
                    String S2 = posts.getResults().get(count).getsummary_short();
                    mydata.add(new ResultObject(S1, S2));
                    count ++ ;
                }
                //listViewresult.
                myJsondataAdapter apdt  = new myJsondataAdapter(getApplicationContext(), mydata);

                listViewresult.setAdapter(apdt);

                pgr.setVisibility(View.GONE); */
            }

            @Override
            public void onFailure(Call<Post> call, Throwable t) {
               //Toast.makeText(getApplicationContext(), t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                return ;

            }
        });


        return postData;
    }
}
