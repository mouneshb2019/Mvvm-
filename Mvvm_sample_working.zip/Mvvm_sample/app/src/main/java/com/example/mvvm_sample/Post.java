package com.example.mvvm_sample;

public class Post {

    private int num_results ;
    private String copyright;
    private String status;

    public int getNum_results() {
        return num_results ;
    }

    public String getcopyright() {
        return copyright;
    }

    public void setcopyright(String title) {
        this.copyright = copyright ;
    }

    public void setstatus(String title) {
        this.status = status;
    }

    public String getstatus() {
        return status;
    }

    public void setNum_results(int values ) {
        num_results = values;
    }

}
