package com.example.mvvm_sample;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private MainActivityViewModel mMainActivityViewModel;
    private TextView num_results;
    private TextView copyright;
    private TextView status;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num_results = findViewById(R.id.textView7);
        copyright = findViewById(R.id.editText);
        status = findViewById(R.id.textView10);

        final ProgressBar pgr = findViewById(R.id.progressBar);
        pgr.setVisibility(View.VISIBLE);

        mMainActivityViewModel = ViewModelProviders.of(this).get(MainActivityViewModel.class);
        mMainActivityViewModel.queryrepo();
        mMainActivityViewModel.getPost().observe(this, new Observer<Post>() {
            @Override
            public void onChanged(@Nullable Post post) {

                pgr.setVisibility(View.INVISIBLE);
                int resval = post.getNum_results();
                String val = Integer.toString(resval);
                num_results.setText(val.toString());
                copyright.setText(post.getcopyright());
                status.setText(post.getstatus());
            }
        });


    }
}
