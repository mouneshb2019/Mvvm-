package com.example.mvvm_sample;

import retrofit2.Call;
import retrofit2.http.GET;

public interface JsonPlaceholderApi {

    // @GET("/typicode/demo/posts")
    // @GET("v2/5ca5ede4330000cd522eaa66")
    @GET("reviews/search.json?query=godfather&api-key=pgmDOO5zATkiqZvhbiIXiQgK58wyhH4G")
    Call<Post> getPosts();

    //@GET("reviews/search.json?query=godfather&api-key=pgmDOO5zATkiqZvhbiIXiQgK58wyhH4G")
    //Call<List<Users>> getUsers();

}
