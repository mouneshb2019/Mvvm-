package com.example.mvvm_sample;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

public class MainActivityViewModel extends ViewModel {
    private LiveData<Post> mypost ;
    private PostRepository postRepo;

    //Query for userRepository
    public void queryrepo() {
        postRepo = PostRepository.getInstance() ;
        mypost =  postRepo.getDatawithRetrofit();
    }
     public LiveData<Post> getPost() {
        return mypost ;
    }




}
